//Task 3
Ci,0 = (Pi-2 + 11Pi-1 + 11Pi + Pi+1)/24
Ci,1 = (4Pi-1 + 7Pi + Pi+1)/12
Ci,2 = (Pi-1 + 4Pi + Pi+1)/6
Ci,3 = (Pi-1 + 7Pi + 4Pi+1)/12
Ci,4 = (Pi-1 + 11Pi + 11Pi+1 + Pi+2)/24

//Task 5
Even though it is so close to a circle, it is actually not.
This is because Bezier curves are commonly used to simulate a circle with four or eight segments.
However if we do precise calculations on the t=0 and t=0.5, we can see that the location of t=0 point is ((10+sqrt(2))/24, (12+11*sqrt(2))/24).
While the location of t=0.5 point is ((115+38*sqrt(2))/192, (115+38*sqrt(2))/192)).
The distance of point t=0 towards center is 1.242782 approximately, and of t=0.5 is 1.242888. There is 0.008% difference between these two.
I would say this is a prefect approximation.
